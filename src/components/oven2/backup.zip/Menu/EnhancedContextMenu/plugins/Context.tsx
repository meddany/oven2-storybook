// @ts-nocheck
import { createContext } from "react";
const EnhancedMenuContext= createContext(false)
export default EnhancedMenuContext