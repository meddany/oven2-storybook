// @ts-nocheck
import { SpinnerCustom } from "../../components/oven2/Nextui";
import { useRef } from "react";

export default {
    title : 'Components/Spinner' , 
    component : SpinnerCustom  , 
    args : {

    }
}


const Template = args => {
    const ref = useRef()
    return(
        <div style={{width : '30vw' , height :'30h' , marginTop : '20px' , marginLeft : '20px'}} >
            <SpinnerCustom ref={ref} {...args} />
        </div>
    )
} 

export const Basic = Template.bind({})
