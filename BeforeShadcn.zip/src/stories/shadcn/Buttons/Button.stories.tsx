// @ts-nocheck
import { useRef } from "react";
import { Button } from "@/components/nextgen";

export default {
    title : 'Shadcn/Components/Button' , 
    component : Button  , 
    args : {

    }
}


const Template = args => {
    const ref = useRef()
    return(
        <div style={{width : '30vw' , height :'30h' , marginTop : '20px' , marginLeft : '20px'}} >
            <Button ref={ref} {...args} />
        </div>
    )
} 

export const Basic = Template.bind({})
