// @ts-nocheck
import { Button } from '@/components/ui/button'

import React from 'react'

export const TButton = () => {
  return (
    <Button> TEST PLEASE </Button>
  )
}



