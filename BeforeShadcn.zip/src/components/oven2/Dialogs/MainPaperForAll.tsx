// @ts-nocheck
import React from 'react'


export default function MainPaperForAll() {
  return (
    <div>MainPaperForAll</div>
  )
}
