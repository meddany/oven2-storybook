// @ts-nocheck
export function ProtoTypes(){
    this.this = {}
}