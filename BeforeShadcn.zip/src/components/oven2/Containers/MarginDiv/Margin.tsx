// @ts-nocheck
import React from 'react'


export default function MarginBox(props) {
  return (
    <div style={{ marginLeft : `${props.marginLeft}px` ,marginTop : `${props.margin}px`}}></div>
  )
}
