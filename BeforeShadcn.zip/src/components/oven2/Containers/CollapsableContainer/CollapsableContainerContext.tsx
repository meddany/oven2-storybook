import React from 'react';

// Create a Context
const CollapsableContainerContext = React.createContext({});

export default CollapsableContainerContext;