// @ts-nocheck
import React from 'react'

export default function ManageColumns(props) {
  return (
    <div>ManageColumns</div>
  )
}
