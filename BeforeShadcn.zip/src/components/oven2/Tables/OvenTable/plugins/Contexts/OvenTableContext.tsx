import React from 'react';

// Create a Context
const OvenTableContext = React.createContext(false);

export default OvenTableContext ;
