import React from 'react';

// Create a Context
const GlobalActiveTab = React.createContext(false);

export default GlobalActiveTab ;
