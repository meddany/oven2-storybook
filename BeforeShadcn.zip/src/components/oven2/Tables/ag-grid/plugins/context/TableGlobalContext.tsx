import React from 'react';

// Create a Context
const TableGlobalContext = React.createContext(false);

export default TableGlobalContext ;
